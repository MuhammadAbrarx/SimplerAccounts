'use strict';

/**
 * @ngdoc function
 * @name electroCrudApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the electroCrudApp
 */
angular.module('electroCrudApp')
  .controller('AboutCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
