'use strict';

var Reflux = require('reflux');

var FormPropsComponentEditorActions = Reflux.createActions([
    'cancelWizard',
    'startWizardSaveVariant',
    'submitWizardSaveVariant'

]);

module.exports = FormPropsComponentEditorActions;

