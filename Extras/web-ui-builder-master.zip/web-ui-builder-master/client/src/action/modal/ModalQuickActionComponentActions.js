'use strict';

var Reflux = require('reflux');

var ModalQuickActionComponentActions = Reflux.createActions([
    'show',
    'hide'
]);

module.exports = ModalQuickActionComponentActions;
