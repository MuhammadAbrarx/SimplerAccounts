'use strict';

var Reflux = require('reflux');

var FormAvailableComponentsActions = Reflux.createActions([
    'setFilter'
]);

module.exports = FormAvailableComponentsActions;

